// Add your Stripe Price IDs here after creating one-time prices in Stripe.
// Each used item should normally have quantity 1.
export const products = {
  "example-electronics": {
    name: "Example Electronics Item",
    description: "Replace with the exact condition and included accessories.",
    priceId: "price_REPLACE_ME",
    image: "",
    active: true
  },
  "example-clothing": {
    name: "Example Clothing Item",
    description: "Replace with brand, size, condition and measurements.",
    priceId: "price_REPLACE_ME",
    image: "",
    active: true
  }
};
