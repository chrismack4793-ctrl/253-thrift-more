import express from "express";
import Stripe from "stripe";
import { products } from "./products.js";

const app = express();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const PORT = process.env.PORT || 4242;

app.use(express.json());
app.use(express.static("public"));

app.post("/create-checkout-session", async (req, res) => {
  try {
    const product = products[req.body.productId];
    if (!product || !product.active || product.priceId === "price_REPLACE_ME") {
      return res.status(400).json({error: "This item is not configured for checkout yet."});
    }

    const origin = req.headers.origin || `http://localhost:${PORT}`;

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [{price: product.priceId, quantity: 1}],
      success_url: `${origin}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/?canceled=1`,
      billing_address_collection: "auto",
      shipping_address_collection: {allowed_countries: ["US"]},
      automatic_tax: {enabled: true},
      metadata: {product_id: req.body.productId}
    });

    res.json({url: session.url});
  } catch (err) {
    console.error(err);
    res.status(500).json({error: "Unable to start checkout."});
  }
});

app.listen(PORT, () => console.log(`253 Thrift & More running on http://localhost:${PORT}`));
