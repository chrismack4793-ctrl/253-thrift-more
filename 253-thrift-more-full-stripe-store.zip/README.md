# 253 Thrift & More — full Stripe Checkout starter

This version uses Stripe Checkout Sessions on the server instead of exposing a Stripe secret key in the browser.

## Run locally
1. Install Node.js.
2. Copy `.env.example` to `.env`.
3. Put your Stripe test secret/restricted key in `.env`.
4. Run `npm install`
5. Run `npm start`
6. Open http://localhost:4242

## Add a product
Create a Product and one-time Price in Stripe. Put the resulting `price_...` ID into `products.js`. Then edit the matching listing in `public/index.html`.

## Tax
The checkout code has automatic tax enabled. Before relying on it for real transactions, configure Stripe Tax and make sure your business has the required tax registration(s). Stripe Tax does not replace registration obligations.

## Inventory
For unique used goods, keep each item at quantity 1 and deactivate/remove the listing when sold. For production, add a database and webhook-driven inventory reservation/fulfillment system so concurrent checkouts cannot oversell an item.

## Production security
Keep the server-side Stripe key in an environment/secret manager. Never put `sk_` or `rk_` keys in browser JavaScript or HTML. Use HTTPS in production.
